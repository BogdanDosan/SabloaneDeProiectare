package services;

public interface AlignStrategy {
    String align(String s);
}