package models;

public interface Visitee {
    public void accept(Visitor visitor);
}